<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              piwebsolution.com
 * @since             1.0
 * @package           Pisol_Pickup_Location_Date_Time
 *
 * @wordpress-plugin
 * Plugin Name:       Allow shop manager to change plugin settings
 * Plugin URI:        piwebsolution.com
 * Description:       Allow shop manager to change plugin settings 
 * Version:           1.0
 * Author:            PI Websolution
 * Author URI:        piwebsolution.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pisol-pickup-location-date-time
 * Domain Path:       /languages
 * WC tested up to: 5.2.2
 */
/**
 * this will work from version 3.3.6.1
 */
class pisol_dtt_allow_shop_manager{

	function __construct(){
		add_filter('pisol_dtt_settings_cap', array(__CLASS__, 'returnCap'));

		$this->optionEditToShopManager();
	}

	static function returnCap($cap){
		return 'manage_woocommerce';
	}

	function optionEditToShopManager(){
		$settings = array('pisol_dtt_default','pisol_dtt_label', 'pisol_order_limit_day', 'pisol_order_limit_date','pisol_dtt_cart_option','pisol_dtt_day_time_slot','pisol_dtt_day_time','pisol_dtt_pickup_location','pisol_dtt_date','pisol_pccdt_settings');
		foreach($settings as $setting){
			add_filter("option_page_capability_{$setting}", array(__CLASS__, 'returnCap'));
		}
	}
}

new pisol_dtt_allow_shop_manager();