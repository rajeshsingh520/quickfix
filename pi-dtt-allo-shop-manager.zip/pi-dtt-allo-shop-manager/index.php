<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              piwebsolution.com
 * @since             1.0
 * @package           Pisol_Pickup_Location_Date_Time
 *
 * @wordpress-plugin
 * Plugin Name:       Allow shop manager to change plugin settings
 * Plugin URI:        piwebsolution.com
 * Description:       Allow shop manager to change plugin settings 
 * Version:           1.0
 * Author:            PI Websolution
 * Author URI:        piwebsolution.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pisol-pickup-location-date-time
 * Domain Path:       /languages
 * WC tested up to: 5.2.2
 */
/**
 * this will work from version 3.3.6.1
 */
class pisol_dtt_allow_shop_manager{

	function __construct(){
		add_filter('pisol_dtt_settings_cap', array(__CLASS__, 'returnCap'));

		$this->optionEditToShopManager();
	}

	static function returnCap($cap){
		return 'manage_woocommerce';
	}

	function optionEditToShopManager(){
		/** tab setting shop manger can modify */
		$settings = array(
			'General setting'=>'pisol_dtt_default',
			'Labels'=>'pisol_dtt_label', 
			'Order Limit1' => 'pisol_order_limit_day', 
			'Order Limit2'=> 'pisol_order_limit_date',
			'Cart page'=>'pisol_dtt_cart_option',
			'Time Slot'=>'pisol_dtt_day_time_slot',
			'Time range'=>'pisol_dtt_day_time',
			'Pickup location'=>'pisol_dtt_pickup_location',
			'Date setting'=>'pisol_dtt_date',
			'Preparation time master'=>'pisol_pccdt_settings');
		foreach($settings as $setting){
			add_filter("option_page_capability_{$setting}", array(__CLASS__, 'returnCap'));
		}
	}
}

new pisol_dtt_allow_shop_manager();