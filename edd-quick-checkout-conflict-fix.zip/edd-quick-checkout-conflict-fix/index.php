<?php
/*
 * Plugin Name:  conflict fix
 * Description:  conflict fix
 * Version:           1.0
 * Author:            PI Websolution
 * Author URI:        piwebsolution.com
 */

function edd_quick_checkout_conflict_fix_wpdocs_dequeue_script() {
	wp_dequeue_script( 'pi-edd-common' );
	$js = '
	jQuery(document).ready(function($){
	$(document).ajaxComplete(function (event, jqxhr, settings) {
        if (settings.url.includes("wc-ajax=update_shipping_method")) {
            jQuery("[name=\'update_cart\']")
                .removeAttr("disabled")
                .trigger("click")
                .attr("disabled");
        }
	});
	});';
	wp_add_inline_script('jquery', $js, 'after');
}
add_action( 'wp_print_scripts', 'edd_quick_checkout_conflict_fix_wpdocs_dequeue_script', 100 );