<?php
/*
 * Plugin Name:  Add order note for Woocommerce App
 * Description:  Add order note for Woocommerce App
 * Version:           1.0
 * Author:            PI Websolution
 * Author URI:        piwebsolution.com
 */

add_action( 'woocommerce_checkout_update_order_meta', 'pisol_kbaab_add_note_for_delivery',  100, 1  );

function pisol_kbaab_add_note_for_delivery( $order_id ) { 

    $order = wc_get_order($order_id);

    $type = get_post_meta( $order_id, 'pi_delivery_type', true );   // delivery type 'delivery' or 'pickup'
      
    $date = get_post_meta( $order_id, 'pi_system_delivery_date', true ); // date in yyyy/mm/dd format
	if(class_exists('pi_dtt_date')){
		$date = pi_dtt_date::translatedDate($date);
	}

    $time = get_post_meta( $order_id, 'pi_delivery_time', true );  // delivery time
    if(class_exists("pisol_dtt_time")){
    	$time = pisol_dtt_time::formatTimeForDisplay($time);
    }

    $location = get_post_meta( $order_id, 'pickup_location', true ); // pickup location
	
	$note = "Delivery Type: $type";
	$note .= "<br>Data: $date";
	$note .= "<br>Time: $time";
	if(!empty($location)){
		$note .= "<br>Location: $location";
	}
	$order->add_order_note( $note );
	
}