<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}
class pisol_dtt_shipping_option_time_slot{

    private $setting = array();

    private $active_tab;

    private $this_tab = 'day_time_slot';

    private $tab_name = "Time Slot";

    private $setting_key = 'pisol_dtt_shipping_day_time_slot';

    function __construct( $plugin_name, $version ){

        $this->plugin_name = $plugin_name;

        $this->version = $version;

        $this->active_tab = (isset($_GET['tab'])) ? $_GET['tab'] : 'default';

        $this->settings = array(
               
                array('field'=>'pi_general_time_slot_shipping'),

                array('field'=>'pi_time_slot_sunday_shipping'),

                array('field'=>'pi_time_slot_monday_shipping'),

                array('field'=>'pi_time_slot_tuesday_shipping'),

                array('field'=>'pi_time_slot_wednesday_shipping'),

                array('field'=>'pi_time_slot_thursday_shipping'),

                array('field'=>'pi_time_slot_friday_shipping'),

                array('field'=>'pi_time_slot_saturday_shipping'),

                array('field'=>'pi_different_slot_for_sunday_shipping'),
                array('field'=>'pi_different_slot_for_monday_shipping'),
                array('field'=>'pi_different_slot_for_tuesday_shipping'),
                array('field'=>'pi_different_slot_for_wednesday_shipping'),
                array('field'=>'pi_different_slot_for_thursday_shipping'),
                array('field'=>'pi_different_slot_for_friday_shipping'),
                array('field'=>'pi_different_slot_for_saturday_shipping'),
            
            );
        

        if($this->this_tab == $this->active_tab){
            add_action($this->plugin_name.'_tab_content', array($this,'tab_content'));
        }

        add_action($this->plugin_name.'_tab', array($this,'tab'),3);

        $this->register_settings();
    }

    function register_settings(){   

        foreach($this->settings as $setting){
                register_setting( $this->setting_key, $setting['field']);
        }
    
    }

    function tab(){
        ?>
        <a class=" px-3 text-light d-flex align-items-center  border-left border-right  <?php echo ($this->active_tab == $this->this_tab ? 'bg-primary' : 'bg-secondary'); ?>" href="<?php echo admin_url( 'admin.php?page='.sanitize_text_field($_GET['page']).'&tab='.$this->this_tab ); ?>">
            <?php _e( $this->tab_name, 'pisol-dtt' ); ?> 
        </a>
        <?php
    }

    function tab_content(){
       ?>
        <form method="post" action="options.php"  class="pisol-setting-form">
        <?php settings_fields( $this->setting_key ); ?>
        <?php
            echo '<script>';
            foreach($this->settings as $setting){
                $val = get_option($setting['field'], array());
                if(!is_array($val) || count($val) < 1){
                    $val = array();
                }
            ?>
            var <?php echo $setting['field']; ?> = <?php echo json_encode(array_values($val)); ?>;
            <?php
            }
            echo '</script>';
        ?>
        <?php
            foreach($this->settings as $setting){
                new pisol_class_form_dtt_shipping($setting, $this->setting_key);
            }

            $this->timesForm(__('General Time Slot', 'pisol-dtt' ), 'pi_general_time_slot_shipping');

            $this->timesForm(__('Set different time slot for Sunday', 'pisol-dtt' ), 'pi_time_slot_sunday_shipping', 'sunday');

            $this->timesForm(__('Set different time slot for Monday', 'pisol-dtt' ), 'pi_time_slot_monday_shipping',  'monday');

            $this->timesForm(__('Set different time slot for Tuesday', 'pisol-dtt' ), 'pi_time_slot_tuesday_shipping',  'tuesday');

            $this->timesForm(__('Set different time slot for Wednesday', 'pisol-dtt' ), 'pi_time_slot_wednesday_shipping',  'wednesday');

            $this->timesForm(__('Set different time slot for Thursday', 'pisol-dtt' ), 'pi_time_slot_thursday_shipping',  'thursday');

            $this->timesForm(__('Set different time slot for Friday', 'pisol-dtt' ), 'pi_time_slot_friday_shipping',  'friday');

            $this->timesForm(__('Set different time slot for Saturday', 'pisol-dtt' ), 'pi_time_slot_saturday_shipping',  'saturday');
        ?>
        

        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-md my-3" value="<?php echo __('Save Changes','pisol-dtt'); ?>">
        </form>
       <?php
    }

    function timesForm($label, $field_delivery, $overwrite_day = ""){
        if(empty($overwrite_day)){
            $bg = 'bg-primary';
            $hide="";
        }else{
            $bg = 'bg-dark';
            $overwrite_value = get_option('pi_different_slot_for_'.$overwrite_day.'_shipping', "");
            $checked ="";
            $hide =' style="display:none;" ';
            if(!empty($overwrite_value)){
                $checked = ' checked="checked" ';
                $hide="";
            }
        }
        ?>
        <div id="row_sunday" class="row py-2 border-bottom align-items-center <?php echo $bg; ?> text-light">
            <div class="col-9">
            <?php if(empty($overwrite_day)){ ?>
                <h5 class="mt-0 mb-0 py-2 text-light font-weight-light h4"><label for="pi_different_slot_for_<?php echo $overwrite_day; ?>_shipping"><?php echo $label; ?></label></h5>
            <?php }else{ ?>
            <h5 class="mt-0 mb-0 text-light font-weight-light h5"><label for="pi_different_slot_for_<?php echo $overwrite_day; ?>_shipping"><?php echo $label; ?></label></h5>
            <?php } ?>
            </div>
            <?php if(!empty($overwrite_day)): ?>
                <div class="col-3 text-right">
                    <div class="custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" name="pi_different_slot_for_<?php echo $overwrite_day; ?>_shipping" id="pi_different_slot_for_<?php echo $overwrite_day; ?>_shipping" <?php echo $checked; ?>>
                    <label class="custom-control-label" for="pi_different_slot_for_<?php echo $overwrite_day; ?>_shipping"></label>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="row mb-2 pt-2" id="pi_slots_for_<?php echo $overwrite_day; ?>_shipping" <?php echo $hide; ?>>
            <div class="col-12 col-md-12">
                <div class="row align-items-center">
                    <div class="col-7 mt-2">
                        <strong><?php _e('shipping Time slots', 'pisol-dtt' ); ?></strong>
                    </div>
                    <div class="col">
                        <a class="btn btn-primary btn-sm pi_add_time_slot text-light" data-slot="<?php echo $field_delivery; ?>" ><?php _e('Add Time Slot', 'pisol-dtt' ); ?></a>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-12 mt-2">
                        <div id="<?php echo $field_delivery; ?>_container">

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    

}

/* if we have pro version setting for time tab then we can disable this */





