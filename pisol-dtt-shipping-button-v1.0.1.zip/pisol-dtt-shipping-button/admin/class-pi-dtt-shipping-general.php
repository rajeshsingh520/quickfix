<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}
class pisol_dtt_shipping_general{

    private $setting = array();

    private $active_tab;

    private $this_tab = 'default';

    private $tab_name = 'General setting';

    private $setting_key = 'pisol_dtt_shipping_default';

    public $billing_fields = array(
        'billing_first_name'=>'Billing First Name',
        'billing_last_name'=>'Billing Last Name',
        'billing_address_1'=>"Billing Address 1",
        'billing_address_2'=>"Billing Address 2",
        //'billing_country'=>"Billing Country",
        'billing_city'=>"Billing City",
        'billing_state'=>"Billing State",
        'billing_postcode'=>"Billing Postcode",
        'billing_company'=>"Billing Company",
        'billing_phone'=>"Billing Phone"
    );

    function __construct( $plugin_name, $version ){

        $this->plugin_name = $plugin_name;

        $this->version = $version;

        $this->active_tab = (isset($_GET['tab'])) ? $_GET['tab'] : 'default';

        $this->preparation_days = range(0, 100);

        $this->settings = array(
                array('field'=>'color-setting', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Shipping basic settings','pisol-dtt-shipping-button'), 'type'=>'setting_category'),

            
                array('field'=>'pi_datetime_shipping', 'label'=>__('Date and time option','pisol-dtt-shipping-button'),'desc'=>__('Date and time selection option for shipping','pisol-dtt-shipping-button'), 'type'=>'select', 'value'=>array('enable-both'=>__('Enable','pisol-dtt-shipping-button'), 'disable-both'=>__('Disable','pisol-dtt-shipping-button')), 'default'=>"disable-both"), 

                array('field'=>'pi_enable_time_shipping', 'label'=>__('Time option','pisol-dtt-shipping-button'),'desc'=> __('you can enable shipping time option','pisol-dtt-shipping-button'), 'type'=>'select', 'value'=>array('enable-both'=>__('Enabled','pisol-dtt-shipping-button'),'disable-both' =>__('Disabled','pisol-dtt-shipping-button')), 'default'=>"enable"), 
            
            

                array('field'=>'pi_preorder_days_shipping', 'label'=>__('Preorder days','pisol-dtt-shipping-button'), 'desc'=>__('How many days ahead a shipping can be booked','pisol-dtt-shipping-button'), 'type'=>'number', 'default'=>10, 'min'=> 0),

                array('field'=>'pi_order_preparation_days_shipping', 'label'=>__('Order preparation days','pisol-dtt-shipping-button'), 'desc'=>__('How many days you need to prepare some order','pisol-dtt-shipping-button'), 'type'=>'select', 'default'=> 1, 'value'=>$this->preparation_days),

                array('field'=>'pi_order_preparation_hours_shipping', 'label'=>__('Order preparation minutes (only used when order preparation days is zero)','pisol-dtt-shipping-button'), 'desc'=>__('Order preparation time in minutes (only used when order preparation days is ZERO. This should be less then 1440 minutes','pisol-dtt-shipping-button'), 'type'=>'number', 'min'=> 0,'max'=>1439, 'default'=> 60),

                array('field'=>'next-day-cutoff-section', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Same day Shipping Cutoff time (Only useful when order preparation days is 0)','pisol-dtt-shipping-button'), 'type'=>'setting_category'),
                array('field'=>'pi_same_day_shipping_cutoff_time', 'label'=>__('Same Day shipping cutoff time','pisol-dtt-shipping-button'), 'desc'=>__('Once this time goes by today, user cant place a shipping order for today date','pisol-dtt-shipping-button'), 'type'=>'text'),
                
                array('field'=>'next-day-cutoff-section', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Next day shipping Cutoff time (Only useful when order preparation days is less then 2)','pisol-dtt-shipping-button'), 'type'=>'setting_category'),
                
                array('field'=>'pi_next_day_shipping_cutoff_time', 'label'=>__('Next Day shipping cutoff time','pisol-dtt-shipping-button'), 'desc'=>__('Once this time goes by today, user cant place a shipping order for tomorrows date','pisol-dtt-shipping-button'), 'type'=>'text'),

                array('field'=>'color-setting1', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Extra message that you can show for shipping option','pisol-dtt-shipping-button'), 'type'=>'setting_category'), 
                array('field'=>'pi_extra_message_shipping', 'label'=>__('Message shown when shipping type is selected','pisol-dtt-shipping-button'), 'desc'=>__('Message shown when shipping type is selected, Leave empty if you don\'t want to show message','pisol-dtt-shipping-button'), 'type'=>'text', 'default'=>""),

               
                array('field'=>'color-setting', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Shipping type button on checkout form','pisol-dtt-shipping-button'), 'type'=>'setting_category'),

                array('field'=>'pi_shipping_label', 'label'=>__('Shipping label','pisol-dtt-shipping-button'), 'desc'=>__('shipping button label on checkout form','pisol-dtt-shipping-button'), 'type'=>'text', 'default'=>"Shipping"),

               

                array('field'=>'next-day-cutoff-section', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Shipping method to remove when "Delivery" is selected','pisol-dtt-shipping-button'), 'type'=>'setting_category'),

                array('field'=>'pi_view_shipping_method_name', 'label'=>__('View system name of shipping method','pisol-dtt-shipping-button'), 'desc'=>__('When you enable this admin will be able to see the shipping method name on the checkout page and you can use those name in the below setting to hide the shipping method<br><a href="https://youtu.be/_8__cQhANww" target="_blank">Watch video for detail</a>','pisol-dtt-shipping-button'), 'type'=>'switch', 'default'=>"0"),

                array('field'=>'pi_remove_shipping_method_for_delivery', 'label'=>__('Shipping method to be removed for delivery','pisol-dtt-shipping-button'), 'desc'=>__('Add shipping method system name separated by coma <br>example: flat_rate:22, standers_shipping:32','pisol-dtt-shipping-button'), 'type'=>'text', 'default'=>""),
                array('field'=>'pi_no_shipping_method_message_for_local_delivery', 'label'=>__('Message to show when you don\'t do local delivery to a area (zone) ','pisol-dtt-shipping-button'), 'desc'=>__('This message will be show when you dont do Local delivery to a specific area','pisol-dtt-shipping-button'), 'type'=>'text', 'default'=>"We don't offer delivery to this area, try the standard shipping option"),
               
                array('field'=>'next-day-cutoff-section', 'class'=> 'bg-primary text-light', 'class_title'=>'text-light font-weight-light h4', 'label'=>__('Shipping method to remove when "Shipping" is selected','pisol-dtt-shipping-button'), 'type'=>'setting_category'),
                array('field'=>'pi_remove_shipping_method_for_shipping', 'label'=>__('Shipping method to be removed for standard shipping','pisol-dtt-shipping-button'), 'desc'=>__('Add shipping method system name separated by coma <br>example: flat_rate:22, standers_shipping:32','pisol-dtt-shipping-button'), 'type'=>'text', 'default'=>""),
                array('field'=>'pi_no_shipping_method_message_for_standard_shipping', 'label'=>__('Message to show when you don\'t offer standard shipping to a area (zone) ','pisol-dtt-shipping-button'), 'desc'=>__('This message will be show when you don\'t offer any standard shipping to a area','pisol-dtt-shipping-button'), 'type'=>'text', 'default'=>"We don't offer shipping to this area, try the try local delivery"),


                
            );
        

        if($this->this_tab == $this->active_tab){
            add_action($this->plugin_name.'_tab_content', array($this,'tab_content'));
        }

        add_action($this->plugin_name.'_tab', array($this,'tab'),1);
        
        $this->register_settings();

        
    }

    function paymentMethods(){
        $gateways = WC()->payment_gateways->get_available_payment_gateways();
        $enabled_gateways = [];

        if( !empty($gateways) ) {
            foreach( $gateways as $gateway ) {

                if( $gateway->enabled == 'yes' ) {

                    $enabled_gateways[$gateway->id] = $gateway->title;

                }
            }
        }
        return $enabled_gateways;
    }

    function register_settings(){   

        foreach($this->settings as $setting){
                register_setting( $this->setting_key, $setting['field']);
        }
    
    }

    function delete_settings(){
        foreach($this->settings as $setting){
            delete_option( $setting['field'] );
        }
    }

    function tab(){
        ?>
        <a class=" px-3 text-light d-flex align-items-center  border-left border-right  <?php echo ($this->active_tab == $this->this_tab ? 'bg-primary' : 'bg-secondary'); ?>" href="<?php echo admin_url( 'admin.php?page='.sanitize_text_field($_GET['page']).'&tab='.$this->this_tab ); ?>">
            <?php _e( $this->tab_name, 'pisol-dtt-shipping-button' ); ?> 
        </a>
        <?php
    }

    function tab_content(){
       ?>
        <form method="post" action="options.php"  class="pisol-setting-form">
        <?php settings_fields( $this->setting_key ); ?>
        <?php
            foreach($this->settings as $setting){
                new pisol_class_form_dtt($setting, $this->setting_key);
            }
        ?>
        <input type="submit" name="submit" id="submit" class="btn btn-primary btn-md my-3" value="<?php echo __('Save Changes','pisol-dtt-shipping-button'); ?>">
        </form>
       <?php
    }

    
}