<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}
class pisol_dtt_shipping_menu{

    public $plugin_name;
    public $menu;
    
    function __construct($plugin_name , $version){
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        add_action( 'admin_menu', array($this,'plugin_menu') );
        add_action($this->plugin_name.'_promotion', array($this,'promotion'));
    }

    function plugin_menu(){
        
        $menu = add_submenu_page('pisol-dtt',__('Shipping','pisol-dtt-shipping-button'), __('Shipping','pisol-dtt-shipping-button'), 'manage_options', 'pisol-dtt-shipping-button',  array($this, 'menu_option_page'));

        add_action("load-".$menu, array($this,'menu_page_style'));
 
    }

    function menu_option_page(){
        ?>
        <div class="bootstrap-wrapper">
        <div class="container mt-2">
            <div class="row">
                    <div class="col-12">
                        <div class='bg-dark'>
                        <div class="row">
                            <div class="col-12 col-sm-2 py-2">
                            <a href="https://www.piwebsolution.com/" target="_blank"><img class="img-fluid ml-2" src="<?php echo plugin_dir_url(__FILE__); ?>img/pi-web-solution.svg"></a>
                            </div>
                            <div class="col-12 col-sm-10 d-flex text-center small">
                                <?php do_action($this->plugin_name.'_tab'); ?>
                            </div>
                        </div>
                        </div>
                    </div>
            </div>
            <div class="row">
                <div class="col-12">
                <div class="bg-light border px-3">
                    <div class="row">
                        <div class="col">
                        <?php do_action($this->plugin_name.'_tab_content'); ?>
                        </div>
                        <?php do_action($this->plugin_name.'_promotion'); ?>
                    </div>
                </div>
                </div>
            </div>
        </div>
        </div>
        <?php
    }

    function menu_page_style(){
        /* admin side popup */
       
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_style('pi_dtt_shipping_menu_page_style_bootstrap', plugins_url('css/bootstrap.css', __FILE__));

        wp_enqueue_style('pi_dtt_shipping_menu_page_style', plugins_url('css/style.css', __FILE__));
       
        wp_enqueue_style('pi_dtt_shipping_menu_page_style_timepicker', plugins_url('css/jquery.timepicker.min.css', __FILE__));
        wp_enqueue_script( $this->plugin_name.'time_picker', plugin_dir_url( __FILE__ ) . 'js/jquery.timepicker.min.js', array( 'jquery' ), $this->version, false );

        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/pisol-dtt-shipping-button-admin.js', array( 'jquery' ), $this->version, false );
    }

    function promotion(){
        
    }


}