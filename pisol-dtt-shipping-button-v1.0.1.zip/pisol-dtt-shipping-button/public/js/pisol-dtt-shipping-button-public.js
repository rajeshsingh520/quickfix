(function ($) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	function pi_type_change() {
		this.init = function () {
			this.detectChange();
		}

		this.detectChange = function () {
			var parent = this;
			$("input[name=\'pi_delivery_type\']").on("change", function () {
				if ($("input[name=\'pi_delivery_type\']:checked").val() == "shipping") {
					parent.ajaxCall('shipping');
				}
			});
		}

		this.ajaxCall = function (delivery_type, reload) {
			/* IE fix*/
			if (reload === undefined) {
				reload = true;
			}

			var parent = this;
			this.blockUI()
			jQuery.ajax({
				url: window.pi_date_options.ajaxUrl,
				data: {
					'action': "pi_set_delivery_type",
					'type': delivery_type
				},
				success: function () {
					if (reload) {
						location.reload();
					}
					parent.unblockUI();
				}
			})
		}

		this.blockUI = function () {
			jQuery("#pi_checkout_field, #order_review").block({
				message: null,
				overlayCSS: {
					background: "#fff",
					opacity: .6
				}
			});
		}

		this.unblockUI = function () {
			jQuery("#pi_checkout_field, #order_review").unblock();
		}
	}

	function diningFlow() {
		this.init = function () {
			this.type = this.getType();
			if (this.type == 'dining') {

				this.locationSelection();
				this.locationChange();
				this.timeChange();
				this.clearDate();
			}
		}

		this.ifUserHasNoLocation = function () {
			var location_select = jQuery("select[name='pickup_location']");
			var location_radio = jQuery("input[type='radio'][name='pickup_location']");
			if (location_select.length == 0 && location_radio.length == 0) {
				return true;
			}
			return false;
		}

		this.clearDate = function () {
			var parent = this;
			jQuery(document).on('click', "#clear_delivery_date", function () {
				jQuery("#pi_delivery_time").val("").trigger('change');
			})
		}

		this.timeChange = function () {
			var parent = this;
			jQuery(document).on('change', "#pi_delivery_time", function () {
				var date = jQuery("#pi_system_delivery_date").val();
				var time = jQuery("#pi_delivery_time").val();
				parent.getPeopleDropdown(date, time);
			});
		}

		this.getPeopleDropdown = function (date, time) {
			var parent = this;
			this.blockUI();
			jQuery.ajax({
				url: window.pi_date_options.ajaxUrl,
				method: 'POST',
				data: {
					'action': "pi_get_people_dropdown",
					'date': date,
					'time': time
				},
				success: function (res) {
					jQuery("#pi_number_of_people_container").html(res);
					parent.peopleField(true);
					parent.unblockUI();
				}
			})
		}

		this.locationChange = function () {
			var parent = this;
			jQuery(document).on('change', '#pickup_location, .pisol-location-radio:checked', function () {
				var location = parent.getSelectedLocation();
				if (location) {
					parent.setDiningLocation(location);
				}
			});
			jQuery('.pisol-location-radio').trigger('change');
		}

		this.setDiningLocation = function (location_id) {
			var parent = this;
			this.blockUI();
			jQuery.ajax({
				url: window.pi_date_options.ajaxUrl,
				method: 'POST',
				data: {
					'action': "pi_set_dining_location",
					'location_id': location_id
				},
				success: function (res) {
					parent.getDiningTiming();
				}
			})
		}

		this.getDiningTiming = function () {
			var parent = this;
			jQuery.ajax({
				url: window.pi_date_options.ajaxUrl,
				method: 'POST',
				data: {
					'action': "pi_get_dining_timing",
				},
				success: function (response) {
					parent.clearValues();
					window.pi_date_options = JSON.parse(response);
					jQuery(document).trigger('pi_dtt_reassign_date_picker', [response.minDate, response.maxDate, response.allowedDates]);
					parent.locationSelection();
					parent.unblockUI();
				}
			})
		}

		this.locationSelection = function () {
			if (this.isLocationSelected()) {
				this.dateField(true);
				this.timeField(true);
			} else {
				this.dateField(false);
				this.timeField(false);
				this.peopleField(false);
			}
		}

		this.getType = function () {
			return jQuery("input[name='pi_delivery_type']:checked").val();
		}

		this.isLocationSelected = function () {
			var get_location = this.getSelectedLocation();
			if (get_location || this.ifUserHasNoLocation()) {
				return true;
			}
			return false;
		}

		this.getSelectedLocation = function () {
			if (jQuery("#pickup_location").is('select')) {
				return jQuery("#pickup_location").val();
			} else {
				return jQuery("input[name='pickup_location']:checked").val();
			}
		}

		this.dateField = function (show = true) {
			if (show) {
				jQuery("#pi_delivery_date_field").fadeIn();
			} else {
				jQuery("#pi_delivery_date_field").fadeOut();
			}
		}

		this.timeField = function (show = true) {
			if (show) {
				jQuery("#pi_delivery_time_field").fadeIn();
			} else {
				jQuery("#pi_delivery_time_field").fadeOut();
			}
		}

		this.peopleField = function (show = true) {
			if (show) {
				jQuery("#pi_number_of_people_container").fadeIn();
				jQuery("#pi_number_of_people").selectWoo({
					placeholder: jQuery("#pi_number_of_people").data('placeholder'),
					minimumResultsForSearch: -1,
					allowClear: true
				});
			} else {
				jQuery("#pi_number_of_people_container").fadeOut();
				jQuery("#pi_number_of_people_container").html("");
			}
		}

		this.clearValues = function () {
			jQuery("#pi_delivery_date").val("");
			jQuery("#pi_delivery_time").attr('disabled', 'disabled');
			jQuery("#pi_delivery_time").val("").trigger('change');
			jQuery("#pi_number_of_people_container").html("");
			this.initTimeSlot();
		}

		this.initTimeSlot = function () {
			if (jQuery("#pi_delivery_time").length) {
				jQuery("#pi_delivery_time").selectWoo({
					placeholder: window.pi_date_options.selectTimeSlot,
					minimumResultsForSearch: -1,

				});
			}
		}

		this.blockUI = function () {
			jQuery("#pi_checkout_field").block({
				message: null,
				overlayCSS: {
					background: "#fff",
					opacity: .6
				}
			});
		}

		this.unblockUI = function () {
			jQuery("#pi_checkout_field").unblock();
		}
	}

	jQuery(function ($) {
		var delivery_change_obj = new pi_type_change();
		delivery_change_obj.init();

		var diningFlowObj = new diningFlow();
		diningFlowObj.init();


	});


})(jQuery);
