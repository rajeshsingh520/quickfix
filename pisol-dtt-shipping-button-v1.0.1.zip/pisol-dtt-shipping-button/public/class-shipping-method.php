<?php

class pisol_dtt_shipping_button_shipping_method_handler{

    function __construct(){
        add_filter( 'woocommerce_package_rates', array($this, 'filterShippingMethodAsPerDeliveryType'), 100000 );

        add_filter( 'woocommerce_cart_no_shipping_available_html', array($this, 'change_noship_message') );
        add_filter( 'woocommerce_no_shipping_available_html', array($this, 'change_noship_message') );

        add_action('woocommerce_after_shipping_rate', array($this,'getMethodName'),9999,2);

    }

    function getMethodName($method, $index){
        $view_name = get_option('pi_view_shipping_method_name', 0);
        if(current_user_can( 'manage_options' ) && !empty($view_name)){
            echo '<small>System Name: <strong>'.$method->get_id().'</strong></small>';
        }
    }

    function change_noship_message($message) {
        $type = pi_dtt_delivery_type::getType();
        $msg = "";
        if($type == 'delivery'){
            $msg = get_option('pi_no_shipping_method_message_for_local_delivery',"We don't offer delivery to this area, try the standard shipping option");
        }elseif($type == 'shipping'){
            $msg = get_option('pi_no_shipping_method_message_for_standard_shipping',"We don't offer shipping to this area, try the try local delivery");
        }
        if(empty($msg)) return $message;

        return $msg;
    }

    function filterShippingMethodAsPerDeliveryType( $rates ) {
        $type = pi_dtt_delivery_type::getType();
        $methods_to_remove = self::methodsToRemove($type);
        foreach($rates as $key => $rate){
            if(in_array($key, $methods_to_remove)){
                unset($rates[$key]);
            }
        }

        return $rates;
    }

    static function methodsToRemove($type){
        $remove_in_string = pisol_dtt_shipping_get_option("pi_remove_shipping_method_for_{$type}","");
        if(!empty($remove_in_string)){
            $remove_method_array = explode(',',$remove_in_string);
        }else{
            return array();
        }
        
        if(is_array($remove_method_array)) {
            $remove_method_array = array_map('trim', $remove_method_array );
        }

        return  $remove_method_array;
    }

}

new pisol_dtt_shipping_button_shipping_method_handler();