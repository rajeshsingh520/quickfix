<?php

class pisol_dtt_shipping_general_filter{
    function __construct(){
        
       
        add_filter('pisol_dtt_setting_filter_pi_preorder_days', array($this, 'preOrderDays'));
        add_filter('pisol_dtt_setting_filter_pi_order_preparation_days', array($this, 'orderPreparationDays'));
        add_filter('pisol_dtt_setting_filter_pi_order_preparation_hours', array($this, 'orderPreparationHours'));
        add_filter('pisol_dtt_same_day_cutoff_reached', array($this, 'sameDayCutoffReached'),10, 3);
        add_filter('pisol_dtt_next_day_cutoff_reached', array($this, 'nextDayCutoffReached'),10, 3);
        add_filter('pisol_dtt_extra_message_filter', array($this, 'diningMessage'),10, 2);
    }

    function preOrderDays($days){
        $type =  pi_dtt_delivery_type::getType();
        if($type == 'shipping'){
            $days = pisol_dtt_shipping_get_option('pi_preorder_days_shipping',10);
            return $days;
        }
        return $days;
    }

    function orderPreparationDays($days){
        $type =  pi_dtt_delivery_type::getType();
        if($type == 'shipping'){
            $days = pisol_dtt_shipping_get_option('pi_order_preparation_days_shipping',1);
            return $days;
        }
        return $days;
    }

    function orderPreparationHours($minutes){
        $type =  pi_dtt_delivery_type::getType();
        if($type == 'shipping'){
            $minutes = pisol_dtt_shipping_get_option('pi_order_preparation_hours_shipping',60);
            return $minutes;
        }
        return $minutes;
    }

    function diningMessage($msg, $type){
       
        if($type == 'shipping'){
            $msg = pisol_dtt_shipping_get_option('pi_extra_message_shipping',"");
            return $msg;
        }
        return $msg;
    }

    function sameDayCutoffReached($val, $date, $type){
       
        if($type == 'shipping'){
            return self::sameDayCutoffReachedForDining($date, $type);
        }
        return $val;
    }

    function nextDayCutoffReached($val, $date, $type){
        
        if($type == 'shipping'){
            return self::nextDayCutoffReachedForDining($date, $type);
        }
        return $val;
    }

    static function sameDayCutoffReachedForDining($date, $type){
        if(!self::isSameDay($date)) return false;
        
        
        $same_day_cutoff_time = pisol_dtt_shipping_get_option('pi_same_day_shipping_cutoff_time','');
       
        if(empty($same_day_cutoff_time)) return false;
        $current_time = current_time("H:i");
        $current_timestamp = strtotime($current_time);
        $cutoff_timestamp = strtotime($same_day_cutoff_time);
        if(empty($cutoff_timestamp)) return false;

        if($current_timestamp >= $cutoff_timestamp){
            return true;
        }
        return false;
    }

    static function nextDayCutoffReachedForDining($date, $type){
        if(!self::isNextDay($date)) return false;
    
        $next_day_cutoff_time = pisol_dtt_get_setting('pi_next_day_shipping_cutoff_time','');
        
        if(empty($next_day_cutoff_time)) return false;
        $current_time = current_time("H:i");
        $current_timestamp = strtotime($current_time);
        $cutoff_timestamp = strtotime($next_day_cutoff_time);
        if(empty($cutoff_timestamp)) return false;

        if($current_timestamp >= $cutoff_timestamp){
            return true;
        }
        return false;
    }


    static function isSameDay($date){
        $current_date = current_time('Y/m/d');
        if($current_date == $date) return true;
        return false;
    }

    static function isNextDay($date){
        $current_date = current_time('Y/m/d');
        $next_date = date('Y/m/d',strtotime($current_date.' + 1 days'));
        if($next_date == $date) return true;
        return false;
    }
}

new pisol_dtt_shipping_general_filter();