<?php

class pisol_dtt_shipping_date_time{

    function __construct(){
        add_filter('pisol_dtt_setting_filter_pi_datetime', array($this, 'dateTime'));
        add_filter('pisol_dtt_setting_filter_pi_enable_delivery_time', array($this, 'timeOption'));
    }

    function dateTime($datetime){
        $type =  pi_dtt_delivery_type::getType();
        if($type == 'shipping'){
            $datetime = pisol_dtt_shipping_get_option('pi_datetime_shipping','enable-both');
            return $datetime;
        }
        return $datetime;
    }

    function timeOption($time){
        $type =  pi_dtt_delivery_type::getType();
        if($type == 'shipping'){
            $time = pisol_dtt_shipping_get_option('pi_enable_time_shipping','enable-both');
            return $time;
        }
        return $time;
    }
}

new pisol_dtt_shipping_date_time();