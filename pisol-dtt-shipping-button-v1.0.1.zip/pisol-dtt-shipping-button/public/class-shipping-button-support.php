<?php
/**
 * this adds dining support on backend and front end
 */
class pisol_shipping_button{
    function __construct(){
        add_action('pisol_extra_delivery_type_cart', array($this, 'button'));
        add_action('pisol_extra_delivery_type_checkout', array($this, 'button'));
        add_filter('pisol_dtt_custom_delivery_type', array($this, 'supportType'));

        add_filter('pisol_dtt_delivery_type_label_value', array($this, 'diningTypeLabelValue'),20,2);

        add_filter('pisol_dtt_date_label', array($this, 'diningDateLabel'),10,2);
        
        add_filter('pisol_dtt_time_label', array($this, 'diningTimeLabel'),10,2);

        add_filter('pisol_dtt_pickup_location_label', array($this, 'diningLocationLabel'),10,2);

        add_filter( 'woocommerce_form_field_args', array($this, 'adminEditPage'),10, 3 );

        add_filter('pisol_dtt_order_table_delivery_method', array($this, 'deliveryMethod'),10, 2 );

        add_filter('pisol_dtt_front_pickup_location_label', array($this, 'diningLocation'));

    }   

    function supportType($custom_type){
        if(is_array($custom_type)){
             $custom_type[] = 'shipping';
             return $custom_type;
        }else{
            return array('shipping');
        }
    }

    function button($selected_delivery_type){
        ?>
        <input type="radio" class="input-radio " value="shipping" name="pi_delivery_type" id="pi_delivery_type_shipping" <?php  checked($selected_delivery_type, 'shipping' ); ?>><label for="pi_delivery_type_shipping" class="radio"><?php echo esc_html(get_option('pi_shipping_label','Shipping')); ?></label>
        <?php
    }

    function diningTypeLabelValue($label, $type){
        if($type === 'shipping'){
            return __('Shipping','pisol-dtt-shipping-button');
        }
        return $label;
    }

    function diningLocation($label){
        $type =  pi_dtt_delivery_type::getType();
        if($type === 'shipping'){
            return __('Select a dining location','pisol-dtt-shipping-button');
        }
        return $label;
    }

    function diningDateLabel($label, $type){
       
        if($type === 'shipping'){
            return __('Delivery date','pisol-dtt-shipping-button');
        }
        return $label;
    }

    function diningTimeLabel($label, $type){
       
        if($type === 'shipping'){
            return __('Delivery time','pisol-dtt-shipping-button');
        }
        return $label;
    }

    function diningLocationLabel($label, $type){
       
        if($type === 'shipping'){
            return __('Dining location','pisol-dtt-shipping-button');
        }
        return $label;
    }

    function adminEditPage( $args, $key, $value){
        if($key === 'pi_delivery_type'){
            $args['options']['shipping'] = __('Shipping','pisol-dtt-shipping-button');
        }
        return $args;
    }

    function deliveryMethod($val, $type){
        if($type === 'shipping'){
            return '<mark class="order-status status-processing"><span>'.__('Shipping','pisol-dtt-shipping-button').'</span></mark>';
        }
        return $val;
    }
}

new pisol_shipping_button();