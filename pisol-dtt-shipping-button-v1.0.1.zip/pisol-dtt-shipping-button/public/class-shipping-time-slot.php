<?php

class pisol_dtt_shipping_time_slot{

    function __construct(){
        add_filter('pisol_forced_valid_time_slots', array($this, 'getTimeSlot'), 40, 4);
        add_filter('pisol_dtt_selected_location', array($this, 'selectedLocations')); 
    }

    function getTimeSlot($slots, $day, $selected_date, $delivery_type){

        if($delivery_type !== 'shipping') return $slots;
       

        $this->selected_date = $selected_date;
        $this->delivery_type = $delivery_type;
            
        if($this->isGeneralTimeSlotOverWritten($day)){
            $slots = $this->getDaysTimeSlot($day, $delivery_type);
        }else{
            $slots = $this->getGeneralTimeSlots( $delivery_type );
        }

        return $this->filterSlots($slots);
    }

    function getDaysTimeSlot($day, $delivery_type){
        $slots = get_option('pi_time_slot_'.$day.'_'.$delivery_type, array());
        if(empty($slots)) return array();

        return $slots;
    }

    function getGeneralTimeSlots( $delivery_type ){
        $slots = get_option('pi_general_time_slot_'.$delivery_type, array());
        if(empty($slots)) return array();

        return $slots;
    }

    function filterSlots($slots){
        if(empty($slots)) return array();

        $return = $this->removeFilledSlots($slots);
           
        $return1 = $this->removePastTime($return);

        $return2 = $this->customFilter($return1);

        $return3 = $this->convertToString($return2);

        return $return3;
    }

    function removeFilledSlots($slots){
        if(apply_filters('pisol_disable_order_limit_check', false)){
            return $slots;
        }
        
        if(!empty($slots)){
            foreach($slots as $key => $slot){

                $this->removeFiledSlotsByOrder($slots, $slot, $key);
                    
            }
        }
        return $slots;
    }

    function removeFiledSlotsByOrder(&$slots, $slot, $key){
        $order_limit = $slot['order_limit'];
        $slot_string_to_compare = self::slotToString($slot);
        if(!empty($order_limit)){
           
            $time_slot_with_order_count = self::getOrderCountForTimeSlot($this->selected_date, $this->delivery_type, $slot_string_to_compare, $this->location_id);
            
            if($time_slot_with_order_count >= $order_limit){
                unset($slots[$key]);
            }
        }
    }

    function selectedLocations($null){
        $location_id = WC()->session->get("pickup_location", null);
        return $location_id;
    }

    function isGeneralTimeSlotOverWritten($day){
        $overwrite_value = get_option('pi_different_slot_for_'.$day.'_shipping', "");

        if(empty($overwrite_value)) return false;
        
        return true;
    }

    
    static function slotToString($slot){
        $key = pisol_dtt_time::formatTimeForStorage($slot['from']).' - '.pisol_dtt_time::formatTimeForStorage($slot['to']);
        return $key;
    }

    static function getOrderCountForTimeSlot($date, $delivery_type, $slot, $location_id, $people_count = false){
        $cache_key = implode('-',array($date,$delivery_type,$slot));

        if(!$orders = wp_cache_get($cache_key, 'pisol_dtt_shipping')){
            $args = array(
                'limit' => -1,
                'status' => apply_filters('pisol_dtt_order_status_for_limit',array('pending', 'processing', 'on-hold', 'completed')),
                'meta_query' => array(
                    'relation'=>'AND',
                    array(
                        'key' => 'pi_system_delivery_date',
                        'compare' => 'LIKE',
                        'value'   => $date,
                    ),
                    array(
                        'key' => 'pi_delivery_type',
                        'compare' => 'LIKE',
                        'value'   => $delivery_type,
                    ),
                    array(
                        'key' => 'pi_delivery_time',
                        'compare' => 'LIKE',
                        'value'   => $slot,
                    )
                )
            );
            $orders = wc_get_orders($args);
            wp_cache_set($cache_key, $orders, 'pisol_dtt_shipping');
        }
        
        return count($orders);
        
    }

   
    function getDeliveryTimes($order){
        $order_id = version_compare( WC_VERSION, '3.0.0', '<' ) ? $order->id : $order->get_id();
        $delivery_time = get_post_meta( $order_id, 'pi_delivery_time', true );
        return $delivery_time;
    }
    
    function removePastTime($time_array){


        if(!is_array($time_array) || $time_array == ""){
            return "";
        }

        if(!$this->isSelectedDateToday()) return $time_array;
        
        $order_preparation_time = pisol_dtt_get_setting('pi_order_preparation_hours',0);
        $order_preparation_time = $order_preparation_time == "" ? 0 : $order_preparation_time;

        $now = current_time('h:i A');

        $minutes_to_add = "+".$order_preparation_time." minutes";

        $time_limit  = strtotime($minutes_to_add, strtotime($now));
        foreach($time_array as $key => $time){
            if($time['to'] != ""){
                if(strtotime($time['to']) < $time_limit){
                    unset($time_array[$key]);
                }
            }else{
                if($time['from'] != ""){
                    if(strtotime($time['from']) < $time_limit){
                        unset($time_array[$key]);
                    }
                }
            }
        }
        return $time_array;
    }

    function customFilter($return){
        return apply_filters("pisol_dtt_custom_remove_time_slots", $return, $this->selected_date);
    }

    function isSelectedDateToday(){
        $today = current_time('Y/m/d');
        if($this->selected_date == $today){
            return true;
        }
        return false;
    }

    function convertToString($slots){
        $return  = array();
        if(!empty($slots)){
            foreach($slots as $slot){
                $key = pisol_dtt_time::formatTimeForStorage($slot['from']).' - '.pisol_dtt_time::formatTimeForStorage($slot['to']);
                
                $value =  self::removeEmptyTimeFromDisplay(pisol_dtt_time::formatTimeForDisplay($slot['from']), pisol_dtt_time::formatTimeForDisplay($slot['to']));
                $people_can_attend = "";
                if(isset($slot['people_remaining']) && !empty($slot['people_remaining'])){
                    $people_can_attend = sprintf(__(' (%s place available) ','pisol-dtt-shipping-button'), $slot['people_remaining']);
                }
                $return[] = array('id'=>$key, 'text'=>$value.$people_can_attend);
            }
        }
        return $return;
    }  

    static function removeEmptyTimeFromDisplay($from, $to){
        if(!empty($from) && !empty($to)){
            return $from.' - '.$to;
        }

        if(!empty($from) && empty($to)){
            return $from;
        }

        if(empty($from) && !empty($to)){
            return $to;
        }
        return "";
    }   
}
new pisol_dtt_shipping_time_slot();