<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              piwebsolution.com
 * @since             1.0.1
 * @package           Pisol_Dtt_Shipping_Button
 *
 * @wordpress-plugin
 * Plugin Name:       Shipping option for DTT plugin
 * Plugin URI:        piwebsolution.com
 * Description:       Shipping option for DTT plugin
 * Version:           1.0.1
 * Author:            PI Websolution
 * Author URI:        piwebsolution.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pisol-dtt-shipping-button
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if(!is_plugin_active( 'pi-woocommerce-order-date-time-and-type-pro/pi-woocommerce-order-date-time-and-type-pro.php')){

	function pisol_dinner_activate_dependency() {
        ?>
        <div class="error notice">
            <p><?php _e( 'Please install and active the PI WooCommerce order date time and type PRO plugin, as this plugin is addon plugin', 'pisol-dtt-shipping-button' ); ?></p>
        </div>
        <?php
    }
    add_action( 'admin_notices', 'pisol_dinner_activate_dependency' );
    return;

}else{

/**
 * Currently plugin version.
 * Start at version 1.0.1 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'PISOL_DTT_SHIPPING_BUTTON_VERSION', '1.0.1' );

function pisol_dtt_shipping_get_option($variable, $default=""){
    $value = get_option($variable,$default);
    return apply_filters('pisol_dtt_shipping_option_filter_'.$variable, $value, $variable, $default);
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-pisol-dtt-shipping-button-activator.php
 */
function activate_pisol_dtt_shipping_button() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-pisol-dtt-shipping-button-activator.php';
	Pisol_Dtt_Shipping_Button_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-pisol-dtt-shipping-button-deactivator.php
 */
function deactivate_pisol_dtt_shipping_button() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-pisol-dtt-shipping-button-deactivator.php';
	Pisol_Dtt_Shipping_Button_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_pisol_dtt_shipping_button' );
register_deactivation_hook( __FILE__, 'deactivate_pisol_dtt_shipping_button' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-pisol-dtt-shipping-button.php';

add_action('init', 'pisol_dtt_shipping_update_checking');
function pisol_dtt_shipping_update_checking()
{
    new pisol_update_notification_v1(plugin_basename(__FILE__), PISOL_DTT_SHIPPING_BUTTON_VERSION);
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.1
 */
function run_pisol_dtt_shipping_button() {

	$plugin = new Pisol_Dtt_Shipping_Button();
	$plugin->run();

}
run_pisol_dtt_shipping_button();

}