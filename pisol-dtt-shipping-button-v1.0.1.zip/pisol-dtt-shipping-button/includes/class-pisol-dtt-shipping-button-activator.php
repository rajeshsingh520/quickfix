<?php

/**
 * Fired during plugin activation
 *
 * @link       piwebsolution.com
 * @since      1.0.0
 *
 * @package    Pisol_Dtt_Shipping_Button
 * @subpackage Pisol_Dtt_Shipping_Button/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Pisol_Dtt_Shipping_Button
 * @subpackage Pisol_Dtt_Shipping_Button/includes
 * @author     PI Websolution <sales@piwebsolution.com>
 */
class Pisol_Dtt_Shipping_Button_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
